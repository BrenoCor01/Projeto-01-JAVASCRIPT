//1° - parte dos imports
import './App.css'

//2° parte - funçao
function bia(){
  return(
    <div>
      <h2>Oii, meu nome é Beatriz</h2>
      <p>Estou aprendendo React</p>
    </div>
  )
}

//3° parte - exportando função
export default bia
